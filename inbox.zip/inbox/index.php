
<?php
session_start();

$_SESSION['id']="470882661";

 $url_main="auftera.com";

$id=$_SESSION['id'];
$email=$_SESSION['email'];

$acc_id=$_SESSION['acc_id'];



?>






<html><head>

<base target='_parent' />
<link rel="preconnect" href="https://fonts.gstatic.com">

<link href="https://res.cloudinary.com/heptera/image/upload/v1637123070/auftera-brand/Untitled-1_oumpcf.png" rel="icon" type="image/png">
<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

<link rel="stylesheet" type="text/css" href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1628745601/loader_ww3kdih.css">

<link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1601356785/font-owsome/all_epmuwn.css" rel="stylesheet">



<link type="text/css" href="https://uicdn.toast.com/tui-color-picker/v2.2.6/tui-color-picker.css" rel="stylesheet">
        <link rel="stylesheet" href="https://uicdn.toast.com/tui-image-editor/latest/tui-image-editor.css">




<script src="https://cdn.quilljs.com/1.3.6/quill.js"></script>
<style type="text/css">


.sd-con-ico.dsc-inln-flx {
    width: 8%;
    height: 100%;
}

.tooltip-arrow {

    }


[data-popper-placement="right"]>.tooltip-arrow{

transform: none !important;
    top: 8px !important;

}
.main-con-of-crm.dsc-inln-flx {
    width: 92%;
    height: 100%;
    float: right;
    background: #fafafa;
    overflow: scroll;
    display: inline-flex;

}

    .dsc-inln-flx {
    display: inline-block;
}

.sd-hd-con {
    height: 10vh;
    text-align: center;
    }

    .icon-con-of-sd {
    height: 90vh;
    width: 100%;
}

.icon-main-con {
    height: auto;
    width: 100%;
    position: relative;
    top: 50%;
    -ms-transform: translateY(-50%);
    transform: translateY(-50%);
    }

    .con-ico {
      text-align: center;
    width: 50px;
    margin: auto;
    border-radius: 100px;
    padding: 10px;
    margin-top: 20px;

}

.con-ico:hover {
    background: #e5e5e5;
  }
img.con-of-ico-img {
    height: 30px;
    }




.con-of-main-splt {
    width: 20%;
    height: 100vh;
    display: inline-block;

}
.sd-hd-con {
    height: 10vh;
    text-align: center;
    }


h2.head-od-dt-shw {
    margin: 0px;
    }


button.btn-of-drk-back {
    height: 6vh;
    width: 100%;
    background: #125ef6;
    border: 0px;
    border-radius: 5px;
    color: white;
}

.con-of-dt-sel-ele {
    height: 80vh;
    width: 100%;
    overflow: scroll;
    }

    .container-2GnNH {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -ms-flex-direction: row;
    flex-direction: row;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    padding: 15px;
}
a.com-for-lnk {
    text-decoration: none;
    color: black;
    }

    h2.head-od-dt-shw {
    margin: 0px;
    font-family: lato;
    font-size: 15px;
    font-weight: bolder;
}
.con-of-main-splt {
    width: 20%;
    height: 100vh;
    background: #e5eafc30;
    }


    .eml-add-main-con {
    width: 29%;
    height: 100vh;
    display: inline-block;
    vertical-align: top;
    margin: 0;
    padding: 0;
    font-size: 16px;

}

.sd-hd-con {
    height: 10vh;
    text-align: center;
    }
    input.srch-ip-fld {
    width: 100%;
    height: 3vh;
    border: none;
    font-family: 'Lato';
    font-weight: 500;
    color: #c7ccd7;
}
.con-of-full-email-dt {
    width: 100%;
    height: 90vh;
    }

    .img-eml-ico-con {
    font-family: 'Lato';
    padding: 15px;
    border-radius: 50%;
    background: pink;
    margin-right: 10px;
    color: #ca1938;
}
.sub-ln-of-email-txt {
    width: 240px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    font-family: 'Lato';
    color: #908c8c;
    font-size: 13px;
}
input.srch-ip-fld:focus{
    outline: none;
    border: none;
}

    .fnt-ico-sel {
    width: 20px;
    text-align: center;
}


div#confirm_arch_all {
    z-index: 10000000;
}
.con-of-cht-usr {
    width: 50%;
    display: inline-block;
    height: 100vh;
    display: inline-block;
    vertical-align: top;
    margin: 0;
    padding: 0;
    border-left: 1px solid #f2f2f2;
    }



    .cp-round:after{
           border-top: solid 3px #564f4e;


       }


.con-ico:hover{
    cursor: pointer;
}

.head-of-dash{
    background: #4a154b;
    text-align: right;
    border-bottom-left-radius: 50px;
}


.dropdown-menu .dropdown-item {
    padding: .5rem 1rem;
    font-size: 13px;
    font-weight: 600;
}

button.dropdown-item.comm_up_btn:hover {
    background: #0d66d6;
    color: white;
    }

    .dropdown-header {
    padding: .5rem 1rem;
    color: #f6f9fc;
    font-size: .625rem;
    text-transform: uppercase;
    font-weight: 700;
}
.dropdown-header {
    display: block;
    padding: .5rem 1rem;
    margin-bottom: 0;
    font-size: 0.875rem;
    color: #8898aa;
    white-space: nowrap;
    }
    .dropdown-menu {
    padding: 10px !important;
    box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px !important;
}

.dropdown-item {
    border-radius: 10px;
    }

h6, .h6 {
    font-size: 0.625rem !important;
}


.head-of-inn-con {
    padding: 24px;
}
.all-auta-con {
    padding: 0px 24px;
    }
    span.nm-auta-con {
    font-size: 16px;
    font-weight: 500;
    font-family: 'lato';
    color: #00000080;
}

.crt-new-auta-con {
    width: 200px;
    background: rgb(143 4 175);
    padding: 24px 16px;
    border-radius: 10px;
    height: 200px;
    margin-right: 30px;
    margin-top: 20px;

    margin-left: 20px;
}

    .new-crt-head {
    line-height: 28px;
    font-weight: 700;
    color: white;
    font-family: 'Lato';
}
.con-of-crt-new-img {
    text-align: center;
    width: min-content;
    margin-top: 60px;
    padding: 10px;
    margin-left: auto;
    margin-right: auto;
    border-radius: 50%;
    box-shadow: rgb(0 0 0 / 8%) 0px 2px 4px, rgb(0 0 0 / 6%) 0px 2px 12px, rgb(0 0 0 / 4%) 0px 8px 14px, rgb(0 0 0 / 2%) 0px 12px 16px;
    }

    .crt-new-auta-con:hover{
cursor: pointer;
    }

   .auta-dis-on-dash {
    width: 200px;
    padding: 24px 16px;
    border-radius: 10px;
    background: white;
    margin-right: 30px;
    height: 200px;
    padding-bottom: 0px;
    box-shadow: rgb(0 0 0 / 8%) 0px 2px 4px, rgb(0 0 0 / 6%) 0px 2px 12px;

    margin-top: 20px;
   margin-left: 20px;
}

.auta-dis-on-dash:hover{
    box-shadow: rgb(0 0 0 / 8%) 0px 2px 4px, rgb(0 0 0 / 6%) 0px 2px 12px, rgb(0 0 0 / 4%) 0px 8px 14px, rgb(0 0 0 / 2%) 0px 12px 16px;
cursor: pointer;

}
.main-con-name {
    flex: auto;
    min-height: 116px;
    display: inline-grid;
    width: 100%;
}

    span.bdg-tp-btn {
    margin-left: auto;
    font-size: 12px;
    background: rgb(245, 249, 248);
    padding: 2px 10px;
    border-radius: 10px;
    color: rgb(2, 80, 65);
    font-family: 'Lato';
    font-weight: 600;
    letter-spacing: .4px;
    height: fit-content;
}
.def-name-con-crd {
    display: inline-flex;

}
.ico-of-act-lst {
    width: 40%;
    margin: auto;
    text-align: center;
    padding: 10px;
    width: fit-content;
    border-radius: 10px;
    background: #f2f2f2;
    transition:.4s;
    }

    img.ico-img-src {
    height: 25px;
}
    .def_stat-of-dt {
    padding: 16px 0px;
    display: inline-flex;
    width: 100%;
    height: 60px;
}
.def_stat-of-dt > div {
    font-size: 14px;
    height: fit-content;

}
    .con-of-cnt-data {
    padding: 5.5px 10px;
    background: rgba(0, 0, 0, 0.07);
    border-radius: 5px;
    color: rgb(38, 38, 39);
    width: 60%;
    text-align: center;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
}
.def_stat-of-dt > div {
    font-size: 14px;
    height: fit-content;
    }

    .con-of-dp-data {
    width: 40%;
}

button#dropdownMenuButton {
    background: no-repeat;
    border: none;
    height: 32px;
    padding: 5.5px;
    float: right;
    }

.all-auta-con {
    padding: 0px 24px;
    display: inline-flex;

}
.dropdown-toggle::after{
    display: none;
}

.dropdown-menu.show{
    border: none;
    border-radius: 10px;
}

a.com-for-lnk {
    text-decoration: none;
    color: #00000091;
    }
    .marg-for-temp{
        margin-left: 0px;
        margin-right: 30px;
    }
    .img-temp-of-mark{
        width: 168px;
        height: 166px;
    }










  .ip-by-def-dsg {
    width: 100%;
    background-color: #FFFFFF;
    height: 48px;
    padding-left: 16px;
    padding-right: 16px;
    border-radius: 4px;
    margin: 8px 0px;
    border: 1px solid #B8B8B8;
    font-weight: 400;
    font-size: 14px;
    text-align: left;
    box-sizing: border-box;
    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
    box-shadow: 2px 2px 0 2px transparent;
    text-overflow: ellipsis;
    overflow: hidden;


  }

  .ip-by-def-dsg:focus {
    background-color: #fff;
    outline: 0;
    border-color: #524d52;
    box-shadow: 0 0 0 3px #bdb2bd4d;

    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;

  }



button:disabled,
button[disabled]{
  border: 1px solid #999999;
  background-color: #cccccc;
  color: #666666;
  border: none;
  cursor: not-allowed;
}

.btn-blck-in-auta-fcs{
    display: inline-flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    background-color: rgb(38, 38, 39);
    color: rgb(255, 255, 255);
    position: relative;
    outline: none;
    font-family: inherit;
    border: 0px;
    transition: all 0.4s ease 0s;
    cursor: pointer;
    white-space: nowrap;
    text-decoration: none;
    border-radius: 4px;
    padding: 6px 12px;
    min-height: 32px;
    font-size: 14px;
    line-height: 20px;
    font-family: 'lato';
}

.btn-blck-in-auta-fcs:hover{
    background-color: rgb(71, 71, 71);
    transition: all 0.2s ease 0s;
}

.btn-blck-non-fcs{
    display: inline-flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    background-color: rgb(227, 227, 227);
    color: rgb(38, 38, 39);
    position: relative;
    outline: none;
    font-family: inherit;
    border: 0px;
    transition: all 0.4s ease 0s;
    cursor: pointer;
    white-space: nowrap;
    text-decoration: none;
    border-radius: 4px;
    padding: 6px 12px;
    min-height: 32px;
    font-size: 14px;
    line-height: 20px;
}

.btn-blck-non-fcs:hover{
    background-color: rgb(231, 231, 231);
    transition: all 0.2s ease 0s;
    color: black;
}

.modal-content{
    border-radius: 8px;
}

.btn-blck-non-fcs:focus{
    color: #fff;
    background-color: #313335 !important;
    border-color: #3d3e40 !important;
    box-shadow: 0 0 0 0.2rem rgb(68 70 72 / 50%) !important;
}
.btn-blck-non-fcs:active{

color: #fff;
    background-color: #313335 !important;
    border-color: #3d3e40 !important;
    box-shadow: 0 0 0 0.2rem rgb(68 70 72 / 50%) !important;

}


.con-of-temp-lst {
    display: inline-flex;
    width: 100%;
    padding: 5px 10px;
    border-radius: 10px;
    margin-bottom: 10px;
    }

    .con-of-temp-lst:hover {
    background: #f2f2f28a;
    cursor: pointer;
}

.con-of-temp-lst>div {
    width: 50%;
    }

    span.temp-name {
    font-size: 14px;
}

span.crt-data-of-tmp {
    font-size: 10px;
    }
.row{
    margin-left: 0px;
    margin-right: 0px;
}








.btn-primary.focus, .btn-primary:focus{

    color: #fff;
    box-shadow: 0 0 0 0.2rem rgb(105 109 113 / 50%);
    background-color: rgb(38, 38, 39);
    border-color: rgb(38, 38, 39);

}





.err-menu-cls-dsg{

transition:.2s;
  top: auto !important;
    width: fit-content;
    bottom: 10vh !important;
    padding: 10px;
    background: #000000e8;
    font-size: 13px;
    border-radius: 5px;
    z-index: 100;
    color: white !important;
    display: none;
    z-index: 100000000;
}

#cncl-err-msg:hover{


cursor: pointer;


}



.vert-cent-div {

  height: min-content;
  text-align: center;

  position: absolute;
  top:0;
  bottom: 0;
  left: 0;
  right: 0;

  margin: auto;
}

.switch-dis{
    display: none;
}

.acc-hold-name:hover {
    cursor: pointer;
    background: white;
      }


.mlbx-acc-hold {

    height: 100vh;
    overflow: scroll;
    border-right: 1px solid #d9d0d0;
    padding: 10px;
  }
  .acc-hold-name {
    display: inline-flex;
    padding: 10px;
    width: 100%;
    border-radius: 10px;
    overflow: scroll;
    min-width: 300px;
    font-family: 'lato';
    margin-top: 4px;
  }
  span.con-of-img-pro {
    width: 25%;
  }
  span.con-of-main-name-342 {
    width: 50%;
    font-size: 12px;
    padding: 4px;
    text-align: left;
  }
  span.open-profile-new {
    width: 25%;
    float: right;
    text-align: right;
  }
  img.img-prfdljff-302 {
    height: 48px;
  }
  span.name-txt-327 {
    font-weight: 800;
    font-size: 14px;
    width:200px;
    white-space: nowrap;
  }
  .ico-of-email-rcv {
    width: 48px;
    height: 48px;
    text-align: center;
    padding: 9px;
    margin-right: 10px;
    background: #f200ff;
    border-radius: 50%;
    font-weight: 800px;
    font-size: 20px;
    color: white;
  }
  .email-viewver-final {
    width: 100%;
  }
  .header-of-email-open-fl {
    display: inline-flex;
    width: 90%;
    margin-left: 5%;
    margin-top: 20px;
    border-radius: 100px;
    background: white;
    padding: 10px;
  }
  span.con-of-main-name-342 {
    width: 50%;
    font-size: 12px;
    padding: 4px;
  }
  .main-con-of-send-email {
    background: white;

    margin-top: 10px;
    padding: 10px;
    overflow: scroll;

}

.iframe-height-def{

}
.padd-top-dt {
    padding-top: 10px;
    padding-left: 15px;
  }
  span.head-fin-denot-4637 {
    font-weight: 600;
    color: grey;
    padding-right: 10px;
    font-size: 12px;
  }
  span.head-val-of-dat-58739 {
    color: black;
    font-family: 'lato';
    font-size: 12px;
  }
  .con-of-main-name-345{
    width:75%;
    font-size: 12px;
    text-align: left;
    overflow: scroll;
  }

.main-con-of-dash{
  overflow: hidden;
}
  .dsg-of-det-open-mail {
    width: fit-content;
    min-width: fit-content;
  }

  .app-name-of-usr {
    padding: 10px;
    width: fit-content;
  }

  .main-header-of-ml_bx {
    display: inline-flex;
    width: 100%;
    padding: 10px;
  }
  .ref_email_list {
    width: fit-content;
    padding: 8px;
    margin-right: 10px;
    border-radius: 20px;
    cursor: pointer;
    transition: .5s;
  }
  img.eml-ref-btn-in-db {
    height: 24px;
  }
  .wrapper {
    width: calc(100% - 50px) !important;
    margin: 0px !important;
  }
  .ref_email_list:hover {
    background: white;
    box-shadow: rgba(0, 0, 0, 0.12) 0px 1px 3px, rgba(0, 0, 0, 0.24) 0px 1px 2px;
  }

  div#email-con-of-recienve {
    padding: 10px;
    height: calc(100vh - 80px);
    overflow: scroll;
  }
</style>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.css" integrity="sha512-aOG0c6nPNzGk+5zjwyJaoRUgCdOrfSDhmMID2u4+OIslr0GjpLKo7Xm0Ao3xmpM4T8AmIouRkqwj1nrdVsLKEQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<script src="http://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js" integrity="sha512-uto9mlQzrs59VwILcLiRYeLKPPbS/bT71da/OEBYEwcdNUk8jYIy+D176RYoop1Da+f9mvkYrmj5MCLZWEtQuA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>



<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</head>

<body style="
    margin: 0px;
">





<div class="vert-cent-div err-menu-cls-dsg" id="err_msg_dt_trg" style="display: none;">
<span id="con-of-err-msg"></span>
<span class="cls-err-menu" id="cncl-err-msg">
<i class="fal fa-times-circle" style="
    padding: 6px;
"></i>
</span>
</div>


<div class="main-con-of-dash">



    <?php    require("./confige/header/theme-2.0-side.php");?>
    <div class="main-con-of-crm dsc-inln-flx grid">











  <div class="mlbx-acc-hold  left_inner" style="min-width: 400px;
    max-width: 400px;overflow: hidden;" >

    <div class="main-header-of-ml_bx">
      <div class="ref_email_list"><img id="ref-btn-of-email-list" src="https://res.cloudinary.com/heptera/image/upload/v1657863015/inbox/refresh_FILL0_wght400_GRAD0_opsz48_foiw4j.svg" class="eml-ref-btn-in-db"></div>
  <div class="wrapper" id="act-available-on-email-list">

  <div class="search-input">
  <a href="" target="_blank" hidden=""></a>
  <input type="text" id="srch_data_val" placeholder="Type to search..">
  <div class="autocom-box"><li onclick="select(this)"><span class="spn-of-sug tag-of-sug">subject:</span> is name of list</li><li onclick="select(this)"><span class="spn-of-sug tag-of-sug">to:</span> is email in list</li><li onclick="select(this)"><span class="spn-of-sug tag-of-sug">from:</span> is API template name</li></div>
  </div>
  </div>
      </div>
<div class="app_txt" id="email-con-of-recienve">
</div>


    </div>



    <div class="email-viewver-final left left_inner" id='opened-email-drw'>



        <div class="dropdown">

    <div class="header-of-email-open-fl dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">

        <div class="ico-of-email-rcv" style="background:green">R</div>
        <span class="con-of-main-name-342"><span class="name-txt-327">send email</span><br>ravigorasiya65@gmail.com</span>


    </div>

    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton" style="width: 80%; margin-top: 10px; position: absolute; transform: translate3d(33px, 88px, 0px); top: 0px; left: 0px; will-change: transform;" x-placement="bottom-start">

     <div class="padd-top-dt"> <span class="head-fin-denot-4637">From :</span><span class="head-val-of-dat-58739">ravigorasiya65@gmail.com</span><br>

     </div>
      <div class="padd-top-dt">
         <span class="head-fin-denot-4637">To :</span><span class="head-val-of-dat-58739">admin@builtup.tech</span><br>
  </div>
              <div class="padd-top-dt">
       <span class="head-fin-denot-4637">Date :</span><span class="head-val-of-dat-58739">thurs day 24 2022</span><br>
              </div>
              <div class="padd-top-dt">
      <span class="head-fin-denot-4637">Subject :</span><span class="head-val-of-dat-58739">test email sended</span><br>
              </div>
    </div>
</div>

        <div class="main-con-of-send-email">



                </div>

    </div>







  </div>


<style>

/* CSS */

	.grid {
		display: grid;
		grid-template-columns: 0.2fr 1fr;
		grid-template-rows: 1fr 4fr;
        grid-gap: 3px;
		position: relative;
	}

	.left {
		grid-row: 1 / span 2;
	}

	.right_top {
		grid-column: 2;
		grid-row: 1;
	}

	.right_bottom {
		grid-column: 2;
		grid-row: 2;
	}

	.left_inner {

		padding: 0;


		height: 100%;
		min-height: 100%;
		text-align: center;
    overflow: scroll;
	}
body{
  font-family: 'lato';
}
	.right_top_inner {
		background-color: #f9cf00;
		padding: 0;
		width: 100%;
		min-width: 100%;
		height: 100%;
		min-height: 100%;
		text-align: center;
	}
  div#email-con-of-recienve {
      padding: 10px;
    }

    #email-con-of-recienve::-webkit-scrollbar {
  display: none;
}

/* Hide scrollbar for IE, Edge and Firefox */
#email-con-of-recienve {
  -ms-overflow-style: none;  /* IE and Edge */
  scrollbar-width: none;  /* Firefox */
}

.left_inner::-webkit-scrollbar {
display: none;
}

/* Hide scrollbar for IE, Edge and Firefox */
.left_inner {
-ms-overflow-style: none;  /* IE and Edge */
scrollbar-width: none;  /* Firefox */
}

.ico-of-action-on-mail {
    padding: 10px;
    width: fit-content;
    float: right;
    border-radius: 10px;
    cursor: pointer;
  }
  .ico-of-action-on-mail:hover {
    background: #80808024;
    cursor: pointer;
  }
  img.img-of-act-ico-data {
    height: 20px;
  }
  img.img-of-act-ico-data {
    height: 20px;
  }
  .reply_email_editor_open {
    height: 200px;
  }
  input.subject-lin-for-chg-rep {
    width: 100%;
    margin-bottom: 10px;
    margin-top: 40px;
    border-radius: 10px;
    border: none;
    box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px;
    font-size: 12px;
    padding: 10px;
  }
  input.subject-lin-for-chg-rep:focus {
    border: none;
    outline: none;
  }
  .ql-container.ql-snow {
    border: none;
  }
  .ql-toolbar.ql-snow {
    border: none;
    border-radius: 5px;
    box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px;
  }
  .send-rep-email-btn {
    float: left;
    background: #094ba3;
    color: white;
    font-family: 'lato';
    font-weight: 400;
    border-radius: 10px;
    padding: 5px 20px;
    font-size: 12px;
    border: none;
    box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px;
  }
  .cp-spinner.cp-round {
    margin-top: 40px;
  }
  p.txt-prev-data-err {
    font-family: 'lato';
    font-size: 12px;
    width: 200px;
    margin: auto;
    font-weight: 500;
    color: grey;
  }
  img.img-fot-error-def-data {
    height: 200px;
    margin-top: 100px;
  }
  input.ip-by-def-dsg.compose_tbl_ip_fld {
    border: none;
    border-bottom: 1px solid #a39d9d;
    border-radius: 0px;
    padding-left: 2px;
    padding-bottom: 0px;
    height: 36px;
    font-family: 'Lato';
  }
  input.ip-by-def-dsg.compose_tbl_ip_fld:focus {
    outline: none;
    box-shadow: none;
  }
  div#style-box-of-compose-data {
    height: 200px;
  }
  span.def-email-to-txt-data {
    padding: 4px 20px;
    background: #0a0c83;
    color: white;
    border-radius: 10px;
    font-size: 12px;
    font-weight: 600;
    margin-right: 10px;
    display: inline-block;
    margin-top: 10px;
  }
  span.def-email-to-txt-data:hover {
    cursor: pointer;
  }
  span.prev-add-data-384 {
    font-size: 12px;
    width: 80px

    padding: 5px;
    color: black;
    font-weight: 500;
  }

.open-emal-frm-id-535.class-id-open-4784 > .con-of-main-name-345 > .name-txt-327{
  font-weight: 400;
}

.iframe-height-def {
    max-height: 500px;
  }
  button.open-full-frame {
    padding: 1px 10px;
    border: none;
    border-radius: 40px;
    float: left;
  }
  img.open-full-email-height-dt {
    height: 14px
}
button.open-full-frame:hover {
    cursor: pointer;
    background: #cdc8c8;
  }
  button.close {
    background: no-repeat;
    border: none;
  }

  .active_part_of_open_tp {
      background: #69086e;
    }
    .active_part_of_open_tp > svg {
    fill: white;
  }
  .active_part_of_open_tp:hover{
    background: #69086e;
  }


::selection{
  color: #fff;
  background: #664AFF;
}

.wrapper {
    width: 90%;
    margin: auto;
    margin-top: 10px;
  }

.wrapper .search-input {
    background: #fff;

    border-radius: 5px;
    position: relative;
    width: 100%;
  }

.search-input input {
    height: 40px;
    width: 100%;
    outline: none;
    border: none;
    border-radius: 5px;
    padding: 0 60px 0 20px;
    font-size: 12px;
    border-radius: 10px !important;
    box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px;
  }
.search-input.active input{
  border-radius: 5px 5px 0 0;
}

.search-input .autocom-box {
    padding: 0;
    opacity: 0;
    pointer-events: none;
    max-height: 280px;
    overflow-y: auto;
  }

.search-input.active .autocom-box {
    padding: 10px 8px;
    opacity: 1;
    pointer-events: auto;
    position: absolute;
    z-index: 10000;
    width: 100%;
    background: white;
    margin-top: 10px;
    box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px;
    border-radius: 10px;
    text-align: left;
  }



.autocom-box li {
    list-style: none;
    padding: 8px 12px;
    display: none;
    width: 100%;
    cursor: default;
    border-radius: 3px;
    font-size: 12px;
  }

  .autocom-box li:hover{
    cursor: pointer;
  }
.search-input.active .autocom-box li{
  display: block;
}
.autocom-box li:hover{
  background: #efefef;
}

.search-input .icon {
    position: absolute;
    right: 0px;
    top: 0px;
    height: 40px;
    width: 55px;
    color: #644bff;
    cursor: pointer;
    padding: 7px;
    text-align: center;
    background: #2f1cbd26;
    border-radius: 10px;
  }
div#temp_to_res > div {
    width: fit-content;
    margin-right: 30px !important;
}

div#temp_to_res {
    display: inline-flex !important;
}
  span.spn-of-sug.tag-of-sug {
    background: #00800038;
    padding: 3px 10px;
    margin-right: 10px;
    border-radius: 5px;
    color: green;
    height: 30px;
  }
  .sel_file_for_act_nwn {
    background: #dbdbdb !important;
  }

  .con-of-opt-all-mail {
      padding: 8px;
      background: white;
      border-radius: 10px;
      box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px;
    }
    span.icon-of-header-action {
    margin-right: 20px;
    padding: 5px;
    border-radius: 40px;
    text-align: center;
  }
  img.icon-for-dlsd-73 {
    height: 20px
}
span.icon-of-header-action:hover {
    cursor: pointer;
  }

  .send-forward-btn-email {
      float: left;
      background: #094ba3;
      color: white;
      font-family: 'lato';
      font-weight: 400;
      border-radius: 10px;
      padding: 5px 20px;
      font-size: 12px;
      border: none;
      box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px;
    }
</style>













<div class="modal" id="compose_email_for_send" tabindex="-1" role="dialog" aria-labelledby="..." style="display: none; z-index: 1054; background: rgba(51, 48, 48, 0.52);" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header" style="
    border-bottom: 0px;
">
        <h5 class="modal-title new-crt-head" id="exampleModalLongTitle" style="
    color: black;
    font-size: 15px;
">Compose New Mail</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"></path>
  <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"></path>
</svg>
        </button>
      </div>
      <div class="modal-body" id="body_of_compose_modal">


      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-blck-non-fcs" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary btn-blck-in-auta-fcs" id="compose_send_btn">Send Compose Mail</button>
      </div>
    </div>
  </div>
</div>

















































</body></html>

<script src="js/suggestions2.js"></script>
<script src="js/script.js"></script>

<script type="text/javascript">
$('[data-toggle="tooltip"]').tooltip();
user_name_of_email="<?php echo $acc_id;?>";

type_of_open_access_now="inbox";
flg_of_act_by_user=0;


open_tp_data_nes=0;
console.log($('.left_inner').resizable());



$(document).on('click','#ref-btn-of-email-list',function(){
  $("#ref-btn-of-email-list").attr("src","https://res.cloudinary.com/heptera/image/upload/v1657864305/inbox/Dual_Ring-1s-200px_1_kwgyo4.gif");
reload_btn_of_data();

})



$(".drop-down-for-mail-ui").hover(function(){
        var dropdownMenu = $(this).children(".dropdown-menu");
        if(dropdownMenu.is(":visible")){
            dropdownMenu.parent().toggleClass("open");
        }
    });


    function validate_available_option_on_list(){

      $("#act-available-on-email-list").html('<div class="search-input"> <a href="" target="_blank" hidden=""></a> <input type="text" id="srch_data_val" placeholder="Type to search.."> <div class="autocom-box"><li onclick="select(this)"><span class="spn-of-sug tag-of-sug">list_name:</span> is name of list</li><li onclick="select(this)"><span class="spn-of-sug tag-of-sug">email:</span> is email in list</li><li onclick="select(this)"><span class="spn-of-sug tag-of-sug">content:</span> is API template name</li><li onclick="select(this)"><span class="spn-of-sug tag-of-sug">tag:</span> is tag of contact</li><li onclick="select(this)"><span class="spn-of-sug tag-of-sug">status:</span> is sending status</li><li onclick="select(this)"><span class="spn-of-sug tag-of-sug">campign:</span> is Name Of Campign Or Time</li></div> </div>');


      if($(".sel_file_for_act_nwn").length>0){

      console.log("selected found");

      $("#act-available-on-email-list").html('<div class="con-of-opt-all-mail"> <span class="icon-of-header-action " id="del_btn_of_act_care"  data-toggle="tooltip" data-placement="top" title="Send To Trash"><img src="https://res.cloudinary.com/heptera/image/upload/v1646028890/crm/delete_sweep_black_36dp_al1lgy.svg" class="icon-for-dlsd-73"></span> <span class="icon-of-header-action" id="send_to_spam_val_def"  data-toggle="tooltip" data-placement="top" title="Send To Spam"><img src="https://res.cloudinary.com/heptera/image/upload/v1645793021/crm/report_black_24dp_xiwhle.svg" class="icon-for-dlsd-73"></span> <span class="icon-of-header-action" id="del_file_and_db_data" data-toggle="tooltip" data-placement="top" title="Delete Permenant"><img src="https://res.cloudinary.com/heptera/image/upload/v1645793125/crm/delete_black_24dp_ia56zg.svg" class="icon-for-dlsd-73"></span> </div>');
      }else{
        $("#act-available-on-email-list").html('<div class="search-input"> <a href="" target="_blank" hidden=""></a> <input type="text" id="srch_data_val" placeholder="Type to search.."> <div class="autocom-box"><li onclick="select(this)"><span class="spn-of-sug tag-of-sug">list_name:</span> is name of list</li><li onclick="select(this)"><span class="spn-of-sug tag-of-sug">email:</span> is email in list</li><li onclick="select(this)"><span class="spn-of-sug tag-of-sug">content:</span> is API template name</li><li onclick="select(this)"><span class="spn-of-sug tag-of-sug">tag:</span> is tag of contact</li><li onclick="select(this)"><span class="spn-of-sug tag-of-sug">status:</span> is sending status</li><li onclick="select(this)"><span class="spn-of-sug tag-of-sug">campign:</span> is Name Of Campign Or Time</li></div> </div>');
      }


      $('[data-toggle="tooltip"]').tooltip();


    }


    function del_file_in_db_file(data_of_arr){

req_arr=JSON.stringify(data_of_arr);

console.log(req_arr);

      $.ajax({
      type: "POST",
      url: "./ajaxfile/del_perma.php",
      data: {arr_of_data:req_arr}
      }).done(function(response1){
      console.log(response1);
json_data_res=JSON.parse(response1);
remove_class_of_all_sel_file();
err_msg_data(json_data_res.message);
      open_email_as_per_selection(user_name_of_email,"status","0");
      })

    }


$(document).on('click','#del_file_and_db_data',function(){

act_array_of_file=create_activity_array();

act_to_del_file_for_act(act_array_of_file,"2");
del_file_in_db_file(act_array_of_file);

})
    $(document).on('click','#send_to_spam_val_def',function(){


      act_to_del_file_for_act(create_activity_array(),"1");
    })

    $(document).on('click','.ico-of-email-rcv',function(){

if($(this).parent('.open-emal-frm-id-535').hasClass('sel_file_for_act_nwn')){
$(this).parent('.open-emal-frm-id-535').removeClass('sel_file_for_act_nwn');
}else{
$(this).parent('.open-emal-frm-id-535').addClass('sel_file_for_act_nwn');
}

validate_available_option_on_list();


    })


    function create_activity_array(){

act_array_built=[];

$(".sel_file_for_act_nwn").map(function(){

val_of_field=$(this).attr('data-target-process');

act_array_built.push(val_of_field);
})


return act_array_built;
    }


    function open_email_as_per_selection(user_name_of_email,search_field,search_val){
      flg_of_act_by_user=1;
validate_available_option_on_list();
console.log(type_of_open_access_now);


      if(type_of_open_access_now=="sent"){

append_active_holder_in_side(".open-send-main-email");
      get_sent_email_address(user_name_of_email,search_field,search_val);
      }else{
        append_active_holder_in_side(".open-user-mail");

        console.log("data is refresh startedd");

      get_all_recieve_email(user_name_of_email,search_field,search_val);

      }

    }

    $(document).on('click','#del_email_message_id',function(){

flg_of_act_by_user=1;
$("#email-con-of-recienve").html('<div class="cp-spinner cp-round"></div>');
append_active_holder_in_side($(this));
open_tp_data_nes=1;
get_all_recieve_email(user_name_of_email,"status","2");

    })

$(document).on('click',"#spam_email_message_id",function(){

  $("#email-con-of-recienve").html('<div class="cp-spinner cp-round"></div>');
  append_active_holder_in_side($(this));

  flg_of_act_by_user=1;

open_tp_data_nes=1;
console.log(user_name_of_email);
  get_all_recieve_email(user_name_of_email,"status","1");
})

function act_to_del_file_for_act(act_arr_data,status_val){

json_req_data=JSON.stringify(act_arr_data);



$.ajax({
type: "POST",
url: "./ajaxfile/del_message_from_db.php",
data: {act_data_array:json_req_data,tag_status_val:status_val}
}).done(function(response1){
console.log(response1);

remove_class_of_all_sel_file();

open_email_as_per_selection(user_name_of_email,"status","0");
})


}

function remove_class_of_all_sel_file(){
  $(".sel_file_for_act_nwn").map(function(){

$(this).removeClass("sel_file_for_act_nwn");

  })
}


    $(document).on('click',"#del_btn_of_act_care",function(){


act_to_del_file_for_act(create_activity_array(),"2");

    })



items=['blue','pink','green','purule'];









function get_sent_email_address(email_client,srch_fld,srch_val){

type_of_open_access_now="sent";
user_name_of_email=email_client;
//validate_available_option_on_list();
append_active_holder_in_side('.open-send-main-email');
flg_of_act_by_user=1;
    $.ajax({
    type: "POST",
    url: "./ajaxfile/get_all_sent_email.php",
    data: {profile_name:email_client,srch_fld:srch_fld,srch_val:srch_val}
  }).done(function(response1) {

    console.log("enter in sent succe");

    $(".eml-ref-btn-in-db").attr("src",'https://res.cloudinary.com/heptera/image/upload/v1657863015/inbox/refresh_FILL0_wght400_GRAD0_opsz48_foiw4j.svg');
    console.log(response1);
flg_of_act_by_user=0;
  if(JSON.parse(response1).length==0){
not_fount_email_in_list("SENTBOX");
  }else{

  init_email_of_recieve(JSON.parse(response1));
}

  })

}


$(document).on('click','.open-send-main-email',function(){
open_tp_data_nes=1;
init_loader_in_email_file();
append_err_data_file_email();
get_sent_email_address($(this).attr("data-target-process"),"status",'0');

})




timeAgo = (date) => {
            var ms = (new Date()).getTime() - date.getTime();
            var seconds = Math.floor(ms / 1000);
            var minutes = Math.floor(seconds / 60);
        var hours = Math.floor(minutes / 60);
        var days = Math.floor(hours / 24);
        var months = Math.floor(days / 30);
        var years = Math.floor(months / 12);

        if (ms === 0) {
            return {"tag_color":"#1c1078","num_of_data":'Just now'};
        } if (seconds < 60) {
            return {"tag_color":"#2312a9","num_of_data":seconds + ' second'};
        } if (minutes < 60) {
            return {"tag_color":"#2612c3","num_of_data":minutes + ' minutes'};
        } if (hours < 24) {
            return {"tag_color":"#3822e7","num_of_data":hours + ' hours'};
        } if (days < 30) {
            return {"tag_color":"#4d38f1","num_of_data":days + ' days'};
        } if (months < 12) {
            return {"tag_color":"#5b48f7","num_of_data":months + ' months'};
        } else {
            return {"tag_color":"#7363f7","num_of_data":years + ' years'};
        }

    }






function init_email_of_recieve(json_data){

str_app="";
for(const val of json_data){

console.log(val);
subject=val['subject'];
from=val['from'];
file_id=val['file_name'];
tm_dt_frm_db_data=timeAgo(new Date(val['date']));

tm_dt_frm_db=tm_dt_frm_db_data.num_of_data;
color_tag_data=tm_dt_frm_db_data.tag_color;
console.log(tm_dt_frm_db);
if(from==user_name_of_email){
from=val['to'];

}

if(val['open']<1){
  cls_for_def_ele="acc-hold-name open-emal-frm-id-535";
}else{
cls_for_def_ele="acc-hold-name  open-emal-frm-id-535 class-id-open-4784";
}
var item = items[Math.floor(Math.random()*items.length)];
  str_app+='<div class="'+cls_for_def_ele+'" data-target-process="'+file_id+'"> <div class="ico-of-email-rcv " style="background:'+color_tag_data+'">'+from[0].toUpperCase()+'</div> <span class="con-of-main-name-345 open-emal-frm-id-533" data-target-process="'+file_id+'"><span class="name-txt-327">'+subject+'</span><br>'+from+'</span><span class="prev-add-data-384">'+tm_dt_frm_db+'</span>  </div>';
}



$("#email-con-of-recienve").html(str_app+'<div class="ui-resizable-handle ui-resizable-e" style="z-index: 90;"></div>');

}


function header_str_init_data(parsed_data){


for(const val of parsed_data){

loc_data=val['meta_data'];

id_of_open_frame=makeid(13);

from_email=(loc_data['from']).replace("<", "&lt").replace(">","&gt");
to_email=(loc_data['to']).replace("<", "&lt").replace(">","&gt");
date_email=(loc_data['date']);
subject_email=(loc_data['subject']);

tm_dt_frm_db_data=timeAgo(new Date(date_email));

tm_dt_frm_db=tm_dt_frm_db_data.num_of_data;
color_tag_data=tm_dt_frm_db_data.tag_color;

body_data=val['parse_data']['body'];
str_of_act_that_impl="";

const d = new Date(date_email);
date_email=d.toString();

str_of_act_that_impl='<div class="message_data_of_action_reply">';
if(user_name_of_email!=from_email){
str_of_act_that_impl+=' <div class="ico-of-action-on-mail open_reply_console" data-reply-from-name="'+val['parse_data']['frm_name']+'" data-reply-to-email="'+val['parse_data']['to_email']+'" data-reply-to-name="'+val['parse_data']['to_name']+'" data-of-reply-date="'+date_email+'" data-of-reply-email="'+from_email+'" data-of-message_is="'+encodeURIComponent(body_data)+'" data-toggle="tooltip" data-placement="top" title="" data-original-title="Reply Email"><img class="img-of-act-ico-data" src="https://res.cloudinary.com/heptera/image/upload/v1645795292/crm/reply_black_24dp_kz6itx.svg"></div>';
}

str_of_act_that_impl+='<div class="ico-of-action-on-mail open_forw_console" data-from-email="'+user_name_of_email+'" data-from-time-date="'+date_email+'" data-from-subject-email="'+subject_email+'"  data-of-message_is="'+encodeURIComponent(body_data)+'" data-toggle="tooltip" data-placement="top" title="" data-original-title="Reply Email"><img class="img-of-act-ico-data" src="https://res.cloudinary.com/heptera/image/upload/v1646065948/crm/forward_black_36dp_r8hwhx.svg"></div></div>';


str_of_init_data='<div class="dropdown"> <div class="header-of-email-open-fl dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <div class="ico-of-email-rcv" style="background:'+color_tag_data+'">'+from_email.charAt(0).toUpperCase()+'</div> <span class="con-of-main-name-342"><span class="name-txt-327">'+from_email+'</span><br>'+to_email+'</span> </div> <div class="dropdown-menu" aria-labelledby="dropdownMenuButton" style="width: 80%; margin-top: 10px; position: absolute; transform: translate3d(33px, 88px, 0px); top: 0px; left: 0px; will-change: transform;" x-placement="bottom-start"> <div class="padd-top-dt"> <span class="head-fin-denot-4637">From :</span><span class="head-val-of-dat-58739">'+from_email+'</span><br> </div> <div class="padd-top-dt"> <span class="head-fin-denot-4637">To :</span><span class="head-val-of-dat-58739">'+to_email+'</span><br> </div> <div class="padd-top-dt"> <span class="head-fin-denot-4637">Date :</span><span class="head-val-of-dat-58739">'+date_email+'</span><br> </div> <div class="padd-top-dt"> <span class="head-fin-denot-4637">Subject :</span><span class="head-val-of-dat-58739">'+subject_email+'</span><br> </div> </div> </div><div class="main-con-of-send-email"> <iframe id="'+id_of_open_frame+'" style="min-height: 300px;" src="./ajaxfile/get_content_html_eml.php?email_file_id='+encodeURIComponent(body_data)+'" class="iframe-height-def" width="100%" title="Iframe Example"></iframe><button class="open-full-frame" data-target-ifram-name="'+id_of_open_frame+'"><img src="https://res.cloudinary.com/heptera/image/upload/v1645959131/crm/more_horiz_black_24dp_uhdfxu.svg" class="open-full-email-height-dt"></button>'+str_of_act_that_impl+'</div>';


map_all_href_mail(id_of_open_frame);

$("#opened-email-drw").append(str_of_init_data);

}

$('[data-toggle="tooltip"]').tooltip();
}


$(document).on('click','.open_forw_console',function(){

from_email=$(this).attr('data-from-email');
subject_email=$(this).attr('data-from-subject-email');
date_from_date=$(this).attr('data-from-time-date');
content_data=$(this).parent(".message_data_of_action_reply").parent(".main-con-of-send-email").children("iframe").contents().find("body").html();

message_of_data_append_rely='<html><head></head><div class="">--------forward--------<br>'+subject_email+'<br>sent at time '+date_from_date+'</div><body> '+content_data+'</body></html>';

console.log(message_of_data_append_rely);
$(".data-of-reply-compose").map(function(){


$(this).remove();

})



$( '<div class="data-of-reply-compose"><div class="input-subject-line-builder"><input class="subject-lin-for-chg-rep" id="forward-email-send-list" placeholder="Enter Email For Forward" /></div><button class="send-forward-btn-email" data-of-subject-email="'+subject_email+'"   append-data-for-forward="'+encodeURIComponent(message_of_data_append_rely)+'" >Send</button></div>' ).insertBefore($(this).parent(".message_data_of_action_reply") );

});

$(document).on('click','.send-forward-btn-email',function(){

val_of_email_list=$("#forward-email-send-list").val();

if(isEmail(val_of_email_list)){
content_of_email_send=decodeURIComponent($(this).attr('append-data-for-forward'));
subject_email_dt=$(this).attr('data-of-subject-email');


send_email_of_compose_new("",val_of_email_list,"",user_name_of_email,subject_email_dt,content_of_email_send,"");
}else{
  err_msg_data("Enter valid Email Address");
}
})


$(document).on('click','.open-full-frame',function(){
obj_height_data={"300px":"700px","700px":"300px"};

val_of_frame_id=$(this).attr('data-target-ifram-name');

console.log($("#"+val_of_frame_id).css("min-height"));
$("#"+val_of_frame_id).css('min-height',obj_height_data[$("#"+val_of_frame_id).css("min-height")]);

})
function map_all_href_mail(id_frame){

$('#'+id_frame).contents().find('a').map(function(){


$(this).setAttribute('target','_blank');

})

}
function makeid(length) {
    var result           = '';
    var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    var charactersLength = characters.length;
    for ( var i = 0; i < length; i++ ) {
      result += characters.charAt(Math.floor(Math.random() *
 charactersLength));
   }
   return result;
}


$(document).on('click','.open_reply_console',function(){


date_of_replied_email=$(this).attr('data-of-reply-date');
from_name_of_email=$(this).attr('data-of-reply-email');

message_of_data_append_rely='<html><head></head><body> <div class="gmail_quote"><div dir="ltr" class="gmail_attr">On '+date_of_replied_email+' &lt;'+from_name_of_email+'&gt; wrote:<br></div> <blockquote class="gmail_quote" style="margin:0px 0px 0px 0.8ex;border-left:1px solid rgb(204,204,204);padding-left:1ex">'+$(this).parent(".message_data_of_action_reply").parent(".main-con-of-send-email").children("iframe").contents().find("body").html()+'</div></blockquote></body></html>';

$(".data-of-reply-compose").map(function(){


$(this).remove();

})

message_id_for_repl=makeid(5);

message_id_for_rep=$(this).attr("data-of-message_is");
reply_email_id_name=$(this).attr("data-of-reply-email");
reply_from_name=$(this).attr("data-reply-from-name");
if(reply_from_name=="From"){
reply_from_name="";
}
reply_email_addr=$(this).attr("data-reply-to-email");
console.log(reply_email_addr);
reply_to_name=$(this).attr("data-reply-to-name");
date_of_replied_email=$(this).attr('data-of-reply-date');
if(reply_to_name=="To"){
  reply_to_name="";
}


$( '<div class="data-of-reply-compose"><div class="input-subject-line-builder"><input class="subject-lin-for-chg-rep" placeholder="Subject Line" data-id-target="'+message_id_for_repl+'-subject-chg"/></div><div class="reply_email_editor_open" id="'+message_id_for_repl+'"></div><button class="send-rep-email-btn" id="'+message_id_for_repl+'-subject-chg" to-email="'+reply_email_id_name+'" from-email="'+reply_email_addr+'" date-of-replied-email="'+date_of_replied_email+'" to-name="'+reply_to_name+'" from-name="'+reply_from_name+'" append-with-replt="'+encodeURIComponent(message_of_data_append_rely)+'" message-id="'+message_id_for_rep+'" subject-line="" body="">Send</button></div>' ).insertBefore($(this).parent(".message_data_of_action_reply") );

var fonts = ['sofia', 'slabo', 'roboto', 'inconsolata', 'ubuntu'];
var fullEditor = new Quill('#'+message_id_for_repl, {
      bounds: '#editor',
      modules: {
        'syntax': true,
        'toolbar': [
          [{ 'size': [] }],
          [ 'bold', 'italic', 'underline', 'strike' ],
          [{ 'color': [] }, { 'background': [] }],
          [{ 'header': '1' }, { 'header': '2' }, 'blockquote', 'code-block' ],
          [{ 'list': 'ordered' }, { 'list': 'bullet'}, { 'indent': '-1' }, { 'indent': '+1' }],
          [ 'link']

        ],
      },
      theme: 'snow'
    });


})


function init_compose_body_editor(){


  var fonts = ['sofia', 'slabo', 'roboto', 'inconsolata', 'ubuntu'];
  var fullEditor = new Quill('.email_con_of_compose-txt', {
        bounds: '#editor',
        modules: {
          'syntax': true,
          'toolbar': [
            [{ 'size': [] }],
            [ 'bold', 'italic', 'underline', 'strike' ],
            [{ 'color': [] }, { 'background': [] }],
            [{ 'header': '1' }, { 'header': '2' }, 'blockquote', 'code-block' ],
            [{ 'list': 'ordered' }, { 'list': 'bullet'}, { 'indent': '-1' }, { 'indent': '+1' }],
            [ 'link']

          ],
        },
        theme: 'snow'
      });
}

$(document).on('click','.compose_trigger_data',function(){


$("#body_of_compose_modal").html('<input type="text" class="ip-by-def-dsg compose_tbl_ip_fld" id="to_email_for_compose"   placeholder="Enter recipient email"><div class="valid_email_tag_def"></div> <input type="text" class="ip-by-def-dsg compose_tbl_ip_fld" id="to_subject_for_compose" style="margin-bottom: 40px;"   placeholder="subject"> <div class="email_con_of_compose-txt" id="style-box-of-compose-data"></div>');
$("#compose_send_btn").attr("data-from-field",$(this).attr('data-target-process'));



init_compose_body_editor();
})

function int_send_compose_email_data(){

content_of_send_reply=$("#style-box-of-compose-data").html()
to_email_co=$("#to_email_for_compose").val();
to_subject_line=$("#to_subject_for_compose").val();

all_arr_of_to_email=to_email_co.split(",");

find_email=0;

if($(".def-email-to-txt-data").length>0){

$(".def-email-to-txt-data").map(function(){

find_email+=1;

  splt_to_arr=$(this).text().split(":");

console.log(splt_to_arr);


  to_name=splt_to_arr[0];
  to_email=splt_to_arr[1];

  frm_name="";
  frm_email=$("#compose_send_btn").attr("data-from-field");

  subject=$("#to_subject_for_compose").val();
  content_of_send_reply=$(".ql-editor").html();

  message_id="";


  send_email_of_compose_new(to_name,to_email,frm_name,frm_email,subject,content_of_send_reply,message_id);



})

setTimeout(function () {

err_msg_data("Email Has Been Sent");

close_modal_in_def("compose_email_for_send");
         }, 500);

        get_sent_email_address(user_name_of_email,"","");

}else{
  delet_loader_in_btn("#compose_send_btn");

err_msg_data("Enter Valid Recipient List each septrated by ' , '");

}

$("#compose_send_btn").prop('disabled',"false");







}

$(document).on('click','#compose_send_btn',function(){
append_loader_in_btn($(this));
int_send_compose_email_data();


})

function isEmail(email) {
  var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
  return regex.test(email);
}
$(document).on('input','#to_email_for_compose',function(){

val_of_data_enter=$(this).val();

if(val_of_data_enter[val_of_data_enter.length -1]==","){


val_of_def_arr_works=val_of_data_enter.split(",");


val_of_def_arr_works=val_of_def_arr_works[0].split(":");
flg_of_find_email=0;
to_name="";
to_email="";

console.log(val_of_def_arr_works);
for(const val of val_of_def_arr_works){
 if(isEmail(val)){
flg_of_find_email=1;
to_email=val;
}else{
  to_name=val;
}



}

if(flg_of_find_email==1){
  $("#to_email_for_compose").val("");
  $(".valid_email_tag_def").append('<span class="def-email-to-txt-data">'+to_name+':'+to_email+'</span>');

}else{

}
}

})

$(document).on('click','.def-email-to-txt-data',function(){


val_of_init_input_field=$(this).text();
$("#to_email_for_compose").val(val_of_init_input_field);
$(this).remove();
})



$(document).on('click','.send-rep-email-btn',function(){


content_of_send_reply=$(".ql-editor").html()+decodeURIComponent($(this).attr("append-with-replt"));

console.log(content_of_send_reply);

to_name=$(this).attr('to-name');
to_email=$(this).attr('to-email');
frm_name=$(this).attr('from-name');
frm_email=$(this).attr('from-email');
subject=$(this).attr('subject-line');
message_id=$(this).attr('message-id');

append_loader_in_btn($(this));

send_email_of_compose_new(to_name,to_email,frm_name,frm_email,subject,content_of_send_reply,message_id);

})


function send_email_of_compose_new(to_name,to_email,frm_name,frm_email,subject,content_to_send,message_id){

  $.ajax({
  type: "POST",
  url: 'http://send-bounce-test.builtup.tech/send/send_reply.php',
  data: {from:frm_email,from_name:frm_name,to_name:to_name,to:to_email,subject:subject,body:content_to_send,message_id:message_id}
}).done(function(response1) {

console.log(response1);


get_sent_email_address(user_name_of_email,"status",'0');

data_parse_of_email(response1);
$(".data-of-reply-compose").remove();


err_msg_data("Email Sent Successfully");


})
}


$('body').on('click','a', function(){
   console.log(this);
 });
$(document).on('input','.subject-lin-for-chg-rep',function(){

targeted_id_data=$(this).attr('data-id-target');

$("#"+targeted_id_data).attr("subject-line",$(this).val());

})





function data_parse_of_email(email_file_id){

  $.ajax({
  type: "POST",
  url: "./ajaxfile/parse_mail.php",
  data: {email_file_id:email_file_id}
}).done(function(response1) {

console.log(response1);
$("#opened-email-drw").empty();


header_str_init_data(JSON.parse(response1));
})
}

$(document).on('click','.open-emal-frm-id-533',function(){

$(this).addClass('class-id-open-4784');

init_loader_in_open_mail();

data_parse_of_email($(this).attr("data-target-process"));
})



function get_all_recieve_email(email,srch_fld,srch_val){





//validate_available_option_on_list();
  type_of_open_access_now="inbox";
  user_name_of_email=email;
  flg_of_act_by_user=1;
  $.ajax({
  type: "POST",
  url: "./ajaxfile/get-all_email_list.php",
  data: {profile_name:email,srch_fld:srch_fld,srch_val:srch_val}
}).done(function(response1) {
$(".eml-ref-btn-in-db").attr("src","https://res.cloudinary.com/heptera/image/upload/v1657863015/inbox/refresh_FILL0_wght400_GRAD0_opsz48_foiw4j.svg");
  console.log(response1);
flg_of_act_by_user=0;
if(JSON.parse(response1).length==0){
not_fount_email_in_list("INBOX");

}else{

init_email_of_recieve(JSON.parse(response1));
}

})
}


function reload_btn_of_data(){

  console.log(type_of_open_access_now);
  if(open_tp_data_nes==0){
  if($("#srch_data_val").val()!=undefined ){
    if(flg_of_act_by_user==0 && $("#srch_data_val").val().length==0 ){

      console.log("inner loop");
  if(type_of_open_access_now=="sent"){

console.log("send email");
  get_sent_email_address(user_name_of_email,"status",'0');
  }else{
  get_all_recieve_email(user_name_of_email,"status",'0');
  }

  }
  }
  }
}


setInterval(function() {

 //validate_available_option_on_list();

reload_btn_of_data();

}, 60 * 2000);



$(document).ready(function(){

append_active_holder_in_side(".open-user-mail");
get_all_recieve_email(user_name_of_email,"status",'0');


})


$(document).on('click',".open-user-mail",function(){

  open_tp_data_nes=1;
append_active_holder_in_side(".open-user-mail");
init_loader_in_email_file();
append_err_data_file_email();
user_name_of_email=$(this).attr("data-target-process");

get_all_recieve_email(user_name_of_email,"status",'0');

})

init_loader_in_email_file();

function init_loader_in_email_file(){

append_err_data_file_email();
$("#email-con-of-recienve").html('<div class="cp-spinner cp-round"></div>');

}


$(document).on('input','#srch_data_val',function(){

val_of_srch_fld=$(this).val();


if(val_of_srch_fld.length==0){
  search_field="";
  search_val="";

  if(type_of_open_access_now=="sent"){

  get_sent_email_address(user_name_of_email,search_field,search_val);
  }else{
  get_all_recieve_email(user_name_of_email,search_field,search_val);
  }

}else{

  if(val_of_srch_fld.search(":")>0){
splt_data_of_src_dt=val_of_srch_fld.split(":");

console.log(splt_data_of_src_dt);

if(splt_data_of_src_dt[1].length>0){

  search_field=splt_data_of_src_dt[0];
  search_val=splt_data_of_src_dt[1];

  if(type_of_open_access_now=="sent"){

  get_sent_email_address(user_name_of_email,search_field,search_val);
  }else{
  get_all_recieve_email(user_name_of_email,search_field,search_val);
  }


}else{

  if(type_of_open_access_now=="sent"){

  get_sent_email_address(user_name_of_email,search_field,search_val);
  }else{
  get_all_recieve_email(user_name_of_email,search_field,search_val);
  }
}

}

}

})


function init_loader_in_open_mail(){

$("#opened-email-drw").html('<div class="cp-spinner cp-round"></div>');

}

function append_err_data_file_email(){

  $("#opened-email-drw").html('<img class="img-fot-error-def-data" src="https://res.cloudinary.com/heptera/image/upload/v1645878951/crm/undraw_select_re_3kbd_ewtebr.svg"><br><br> <p class="txt-prev-data-err">Select Email From Left Side column and prevew here </p>');
}

function append_loader_in_btn(sel){
$(sel).attr("disabled","true");

}

function delet_loader_in_btn(sel){
  $(sel).prop("disabled", false);
}
append_err_data_file_email();



function err_msg_data(message){


$("#con-of-err-msg").html(message);

$("#err_msg_dt_trg").css('display','inline-block');



setTimeout(
    function() {


      $("#con-of-err-msg").empty();
$("#err_msg_dt_trg").css('display','none');

    }, 5000);


}

function close_modal_in_def(modal_id){

$("#"+modal_id).css("display","none");
$(".modal-backdrop").remove();
}

$(document).on('click','#cncl-err-msg',function(){


$("#con-of-err-msg").empty();
$("#err_msg_dt_trg").css('display','none');

})

function append_active_holder_in_side(sel_of_app){

$('.con-ico').map(function(){

$(this).removeClass('active_part_of_open_tp');

})


console.log(sel_of_app);
$(sel_of_app).addClass('active_part_of_open_tp');

}


function not_fount_email_in_list(tp_of_box){


$("#email-con-of-recienve").html('<img class="img-fot-error-def-data" src="https://res.cloudinary.com/heptera/image/upload/v1646021077/crm/undraw_no_data_re_kwbl_o5y2fd.svg"><br><br> <p class="txt-prev-data-err">Not Found Data Into Your '+tp_of_box+'</p>');

}



$(document).click(function() {



$(".search-input").removeClass('active');


});

$(".search-input").click(function(event) {
    add_act (this);

    event.stopPropagation();
});

</script>
