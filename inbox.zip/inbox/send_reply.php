<?php

/**
 * This example shows making an SMTP connection without using authentication.
 */

//Import the PHPMailer class into the global namespace
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;

//SMTP needs accurate times, and the PHP time zone MUST be set
//This should be done in your php.ini, but this is how to do it if you don't have access to that
date_default_timezone_set('Etc/UTC');

function send_email_final_compose($data){


  $from_email=$data['from'];
  $from_name=$data['from_name'];
  $to_name=$data['to_name'];
  $to_email=$data['to'];
  $reply_email=$data['from'];
  $reply_name=$data['from_name'];
  $subject_line=$data['subject'];
  $body=$data['body'];



require './vendor/autoload.php';

//Create a new PHPMailer instance
$mail = new PHPMailer();
//Tell PHPMailer to use SMTP
$mail->isSMTP();
//Enable SMTP debugging
//SMTP::DEBUG_OFF = off (for production use)
//SMTP::DEBUG_CLIENT = client messages
//SMTP::DEBUG_SERVER = client and server messages
$mail->SMTPDebug = SMTP::DEBUG_SERVER;
//Set the hostname of the mail server
$mail->isSendmail();
//We don't need to set this as it's the default value
//$mail->SMTPAuth = false;
//Set who the message is to be sent from
$mail->setFrom($from_email, $from_name);
//Set an alternative reply-to address
$mail->addReplyTo($from_email, $from_name);
//Set who the message is to be sent to

if(isset($data['message_id'])){
$message_id=$data['message_id'];

$mail->addCustomHeader('In-Reply-To', $message_id);
$mail->addCustomHeader('References', $message_id);

}

$mail->addAddress($to_email, $to_name);
$mail->addBcc("response@mailatmars.com");

//$mail->addCustomHeader("Return-Path","<ravigorasiya65+gmail.com-bounces@test5.auftera.email>");

//Set the subject line
$mail->Subject = $subject_line;
//Read an HTML message body from an external file, convert referenced images to embedded,
//convert HTML into a basic plain-text alternative body

//Replace the plain text body with one created manually

//Attach an image file
$mail->Body=$body;

//send the message, check for errors
if (!$mail->send()) {
    echo 'Mailer Error: ' . $mail->ErrorInfo;
} else {
    echo 'Message sent!';
}

}


send_email_final_compose($_GET);
?>
