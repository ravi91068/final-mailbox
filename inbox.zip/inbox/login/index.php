<?php
session_start();


$_SESSION['id']="470882661";
$id=$_SESSION['id'];






 ?>
<html>
<head>

<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<style>

body {
    margin: 0px

    background: rgb(84,14,79);
    background: linear-gradient(68deg, rgba(84,14,79,1) 0%, rgba(139,10,33,1) 100%);

  }

  .body-of-content-data {
    padding: 20px;
    background: white;
    width: fit-content;
    border-radius: 20px;
    margin: auto;
    margin-top: 40px;
    min-width: 400px;
    max-height: 80vh;
    overflow: scroll;
  }
.acc-hold-name.open-emal-frm-id-535 {
  display: inline-flex;
    padding: 5px;
    padding-right: 20px;

}
.ico-of-email-rcv {
    padding: 8.5px;
    border-radius: 100px;
    width: 56px;
    text-align: center;
    color: white;
    font-size: 26px;
    font-family: 'lato';
  }
  span.con-of-main-name-345.open-emal-frm-id-533 {
    padding-left: 10px;
    font-size: 14px;
    padding: 5px;
    padding-left: 10px;
    font-family: 'lato';
  }
  span.name-txt-327 {
    font-family: 'lato';
    font-weight: 700;
  }

  .acc-hold-name.open-emal-frm-id-535:hover{
    background: #dfdfdf;
    cursor: pointer;
    border-radius: 100px;

  }

  .btn-blck-in-auta-fcs {
      display: inline-flex;
      -webkit-box-align: center;
      align-items: center;
      -webkit-box-pack: center;
      justify-content: center;
      background-color: rgb(38, 38, 39);
      color: rgb(255, 255, 255);
      position: relative;
      outline: none;
      font-family: inherit;
      border: 0px;
      transition: all 0.4s ease 0s;
      cursor: pointer;
      white-space: nowrap;
      text-decoration: none;
      border-radius: 4px;
      padding: 6px 12px;
      min-height: 32px;
      font-size: 14px;
      line-height: 20px;
      font-family: 'lato';
    }

    .btn-blck-non-fcs {
    display: inline-flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    background-color: rgb(227, 227, 227);
    color: rgb(38, 38, 39);
    position: relative;
    outline: none;
    font-family: inherit;
    border: 0px;
    transition: all 0.4s ease 0s;
    cursor: pointer;
    white-space: nowrap;
    text-decoration: none;
    border-radius: 4px;
    padding: 6px 12px;
    min-height: 32px;
    font-size: 14px;
    line-height: 20px;
  }

  .ip-by-def-dsg {
    width: 100%;
    background-color: #FFFFFF;
    height: 36px;
    padding-left: 16px;
    padding-right: 16px;
    border-radius: 4px;
    margin: 8px 0px;
    border: 1px solid #B8B8B8;
    font-weight: 400;
    font-size: 14px;
    text-align: left;
    box-sizing: border-box;
    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
    box-shadow: 2px 2px 0 2px transparent;
    text-overflow: ellipsis;
    overflow: hidden;
  }
  button.close {
    background: none;
    border: none;
  }
  .ip-by-def-dsg:focus {
    background-color: #fff;
    outline: 0;
    border-color: #524d52;
    box-shadow: 0 0 0 3px #bdb2bd4d;
    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
  }
.modal-content{
  border-radius: 30px;
font-family: 'lato';
}
.new-account-crt-inbox {
    text-align: center;
    padding: 10px;
    border-radius: 20px;
    cursor: pointer;
}

img.add_account_email {
    height: 36px;
  }
  span.add-acc-txt {
    font-family: 'Lato';
    font-weight: 600;
    padding-left: 20px;
  }
  .new-account-crt-inbox:hover {
    background: #dddcdc;
  }
  table.con-of-dns-reco {
      box-sizing: inherit;
      box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px;
    }
    thead.hd-of-key {
    background: #80808026;
    font-weight: 500;
    color: black;
    font-size: 12px;
  }
  td {
    padding: 10px;
    font-weight: 800;
  }
  tr {
    border-bottom: 1px solid #181a185e !important;
  }
  .con-of-act-dta {
    width: 200px;
    font-size: 12px;
    padding-right: 10px;
    font-weight: 600;
    padding-bottom: 10px;
    color: #6e7176;
    display: inline-flex;
    word-break: break-all;
  }
  .data-of-dns-record{
    overflow: scroll;
  }
</style>
</head>
<body>

<div class="body-of-content-data" id="data-of-append_email-dt">



</div>


<div class="modal" id="crt_new_fold" tabindex="-1" role="dialog" aria-labelledby="..." style="display: none; z-index: 1054; background: rgba(51, 48, 48, 0.52);" aria-hidden="true">
<div class="modal-dialog modal-dialog-centered" role="document">
<div class="modal-content">
<div class="modal-header" style="
    border-bottom: 0px;
">
<h5 class="modal-title new-crt-head" id="exampleModalLongTitle" style="
    color: black;
    font-size: 15px;
">Enter Account Password</h5>
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
<path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"></path>
<path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"></path>
</svg>
</button>
</div>
<div class="modal-body">
<input type="password" class="ip-by-def-dsg" id="ent_pass_data_validate" placeholder="Enter Account Password" >
</div>
<div class="modal-footer">
<button type="button" class="btn btn-secondary btn-blck-non-fcs" data-dismiss="modal">Close</button>
<button type="button" class="btn btn-primary btn-blck-in-auta-fcs" id="valiadte_val_of_email">Login To Account</button>
</div>
</div>
</div>
</div>


<div class="modal" id="crt_new_acc" tabindex="-1" role="dialog" aria-labelledby="..." style="display: none; z-index: 1054; background: rgba(51, 48, 48, 0.52);" aria-hidden="true">
<div class="modal-dialog modal-dialog-centered" role="document">
<div class="modal-content">
<div class="modal-header" style="
    border-bottom: 0px;
">
<h5 class="modal-title new-crt-head" id="exampleModalLongTitle" style="
    color: black;
    font-size: 15px;
">New Email Address</h5>
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
<path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"></path>
<path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"></path>
</svg>
</button>
</div>
<div class="modal-body">

  <div id="step-1-data">
<input  class="ip-by-def-dsg" id="ent_account_email" placeholder="Enter New Email Address" >
</div>
<div class="data-of-dns-record" id="dns-record-container" style="display:none">
<table class="con-of-dns-reco">
<thead class="hd-of-key">
<tr>
<td style="
      ">Type</td>
<td>Name</td>
<td>Value</td>
<td>Priority</td>
</tr>
</thead>
<tbody id="body-of-dns-reco-mail_from" style="">


      </tbody>
</table>
</div>

<div id="data-of-password-ent" style="display:none">
<input  class="ip-by-def-dsg" id="usr_name_of_email" placeholder="Account Name" >
<input  class="ip-by-def-dsg" id="ent_account_pass" placeholder="Account Password" >

</div>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-secondary btn-blck-non-fcs" data-dismiss="modal">Close</button>
<button type="button" class="btn btn-primary btn-blck-in-auta-fcs" id="create_new_account">Next For DNS</button>
</div>
</div>
</div>
</div>
</body>
</html>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script>


id_of_usr="<?php echo $id;?>";

acc_of_crt_email=""
smtp_host_def="bounce.builtup.tech";

function gen_dns_record_for_usr(email){


$("#step-1-data").css("display","none");

domain_email=email.split("@")[1];
smtp_host_def="bounce.builtup.tech";
str_of_dns='<tr style=" border: none; "> <td><div class="con-of-act-dta">MX</div></td> <td><div class="con-of-act-dta"><img src="https://res.cloudinary.com/heptera/image/upload/v1639198362/account/content_copy_black_24dp_1_vudud2.svg" class="ico-for-cp data-of-cp-cb" data-target="'+domain_email+'">'+domain_email+'</div></td> <td><div class="con-of-act-dta"> <img src="https://res.cloudinary.com/heptera/image/upload/v1639198362/account/content_copy_black_24dp_1_vudud2.svg" data-target="'+smtp_host_def+'" class="ico-for-cp data-of-cp-cb">'+smtp_host_def+'</div></td> <td><div class="con-of-act-dta">10</div></td> </tr><tr style=" border: none; "> <td><div class="con-of-act-dta">txt</div></td> <td><div class="con-of-act-dta"><img src="https://res.cloudinary.com/heptera/image/upload/v1639198362/account/content_copy_black_24dp_1_vudud2.svg" class="ico-for-cp data-of-cp-cb" data-target="'+domain_email+'">'+domain_email+'</div></td> <td><div class="con-of-act-dta"> <img src="https://res.cloudinary.com/heptera/image/upload/v1639198362/account/content_copy_black_24dp_1_vudud2.svg" data-target="v=spf1 mx ~all" class="ico-for-cp data-of-cp-cb"> v=spf1 mx ~all</div></td> <td><div class="con-of-act-dta"></div></td> </tr>';


$("#dns-record-container").css("display","block");
$("#body-of-dns-reco-mail_from").html(str_of_dns);

$("#create_new_account").html("verify DNS record");
$("#create_new_account").attr('id','verify-acc-cred');



}


function init_acc_in_db_with_password(){

pass_in_email=$("#ent_account_pass").val();
email_of_usr=acc_of_crt_email;
usr_name=$("#usr_name_of_email").val();

$.ajax({
type: "POST",
url: "./ajaxfile/new_account.php",
data: {account_email:email_of_usr,account_pass:pass_in_email,user_name:usr_name}
}).done(function(response1){

  console.log(response1);

})


}

$(document).on('click','#final_add_in_db',function(){
init_acc_in_db_with_password();

})

function init_acc_in_smtp_serv(){

  $.ajax({
  type: "GET",
  url: "http://"+smtp_host_def+"/send/add_account/",
  data: {client_name:acc_of_crt_email}
  }).done(function(response1){

if(response1==1){
$("#dns-record-container").css("display","none");
$("#data-of-password-ent").css("display","block");
$("#verify-acc-cred").attr('id','final_add_in_db');

}



})

}

function validate_dns_record(){

domain_of_acc=acc_of_crt_email.split("@")[1];

  $.ajax({
  type: "GET",
  url: "./ajaxfile/verify.php",
  data: {domain:domain_of_acc,smtp_host:smtp_host_def}
  }).done(function(response1){

    if(JSON.parse(response1).total==2){
      init_acc_in_smtp_serv();
    }else{
      console.log("try after some time");
    }

  })



}

$(document).on('click','#verify-acc-cred',function(){

validate_dns_record();
})


$(document).on('click','#create_new_account',function(){
acc_of_crt_email=$("#ent_account_email").val();

gen_dns_record_for_usr(acc_of_crt_email);

})

function data_str_of_all_account(data){


str_app="";

for(const val of data){

name_of_acc=val['name'];
email_of_account=val['account'];
logo_charcter=name_of_acc[0].toUpperCase();
  str_app+='<div class="acc-hold-name open-emal-frm-id-535 cli_on_acc_det_ver" data-target-acc-id="'+email_of_account+'" data-toggle="modal" data-target="#crt_new_fold" id="admin@builtup.tech" > <div class="ico-of-email-rcv " style="background:#2612c3">'+logo_charcter+'</div> <span class="con-of-main-name-345 open-emal-frm-id-533"> <span class="name-txt-327">'+name_of_acc+' </span><br>'+email_of_account+' </span> </div><br>';
}

str_app+='<div class="new-account-crt-inbox" data-toggle="modal" data-target="#crt_new_acc" id="add_acc_email_new"> <img src="https://res.cloudinary.com/heptera/image/upload/v1657686375/inbox/add_circle_FILL1_wght400_GRAD0_opsz48_idjoh8.svg" class="add_account_email"><span class="add-acc-txt">Create New Account</span> </div>';

$("#data-of-append_email-dt").html(str_app);

}

$(document).on('click','.cli_on_acc_det_ver',function(){

$("#valiadte_val_of_email").attr("data-target-acc-name-def",$(this).attr('data-target-acc-id'));


})

function validate_email_account_in_db(acc_id,pass){
  $.ajax({
  type: "POST",
  url: "./ajaxfile/valiadte_account.php",
  data: {pass:pass,acc_id:acc_id}
  }).done(function(response1){
  console.log(response1);

data_parsed_json=JSON.parse(response1);

if(data_parsed_json.status==1){

window.location.href=data_parsed_json.message;

}else{

}

  })

}
$(document).on('click','#valiadte_val_of_email',function(){

pass_of_data=$("#ent_pass_data_validate").val();
acc_name_valid=$(this).attr("data-target-acc-name-def");

validate_email_account_in_db(acc_name_valid,pass_of_data);


})

function init_all_account_for_user_id(){


  $.ajax({
  type: "GET",
  url: "./ajaxfile/all_account.php"
  }).done(function(response1){
  console.log(response1);

data_str_of_all_account(JSON.parse(response1));

  })
}
init_all_account_for_user_id();


</script>
