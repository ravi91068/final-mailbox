<?php
session_start();

require("../../confige/crm.confige.php");

function isrt_query_db($conn,$isrt_query){


if($conn->query($isrt_query)){

return 1;

}else{
        return $conn->error;
}


}

$email=$_POST['account_email'];
$pass=$_POST['account_pass'];
$usr=$_POST['user_name'];
$id=$_SESSION['id'];

$isrt_query="insert into `email_account` (usr_id,account,password,name) value ('$id','$email','$pass','$usr')";

if(isrt_query_db($crm_conn,$isrt_query)==1){

  echo json_encode(array("status"=>1,"message"=>"account Is created"));

}else{
echo json_encode(array("status"=>0,"message"=>"account Is created"));

}


 ?>
