<?php
session_start();
$id=$_SESSION['id'];

require("../../confige/crm.confige.php");



function select_query($conn,$sel_query){


        $ret_arr=array();

$result = $conn->query($sel_query);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {


    array_push($ret_arr,$row);
  }
}

return $ret_arr;

}

$acc_id=$_POST['acc_id'];
$pass=$_POST['pass'];

$sel_query_of_account="select * from `email_account` where `usr_id`='$id' and account='$acc_id' and password='$pass'";


$data_val_name=select_query($crm_conn,$sel_query_of_account);

if(count($data_val_name)>0){

$_SESSION['acc_id']=$acc_id;

echo json_encode(array("status"=>1,"message"=>"http://192.168.64.3/auftera/inbox/"));

}else{
echo json_encode(array("status"=>0,"message"=>"Sorry Password Is Incorrect"));
}

?>
