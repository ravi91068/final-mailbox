<?php


$domain="builtup.tech";

print_r(getmxrr("info.bossygifts.net",$mx_details));

print_r($mx_details);
/*
foreach ($txt_record as $key => $value) {

if(strpos($value['entries'][0], ' mx ') !== false && strpos($value['entries'][0], '~all') !== false){


}

}
*/

 ?>
