<?php





$smtp_host=$_GET['smtp_host'];
$domain=$_GET['domain'];
$array_of_rec_ver=array("mx"=>0,"spf"=>0,"dmarc"=>0,"dkim"=>0,"owner"=>0,"total"=>0);

if(dns_get_mx($domain,$mx_details)){
  foreach($mx_details as $key=>$value){

if($value==$smtp_host){
$array_of_rec_ver['mx']=1;
$array_of_rec_ver['total']+=1;
}

  }
}

$txt_record=dns_get_record($domain, DNS_TXT);


foreach ($txt_record as $key => $value) {

if(strpos($value['entries'][0], ' mx ') !== false && strpos($value['entries'][0], '~all') !== false){
$array_of_rec_ver['spf']=1;
$array_of_rec_ver['total']+=1;
}

}

print_r(json_encode($array_of_rec_ver));

 ?>
