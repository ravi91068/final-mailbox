<?php
$servername = "automation-t3.cy6ylr3n4cof.us-east-2.rds.amazonaws.com";
$username = "admin";
$password = "Ravi91068";
$dbname = "auftera-crm";

// Create connection
$crm_conn = mysqli_connect($servername, $username, $password,$dbname);


?>
