#!/bin/bash


walk_dir () {
    shopt -s nullglob dotglob

    for pathname in "$1"/*; do
        if [ -d "$pathname" ]; then
            walk_dir "$pathname" "$2" "$3"
        else
        file_save_name=$pathname"2"
#echo $pathname
sed 's/'$2'/'$3'/g' $pathname > $file_save_name
            rm $pathname
            mv $file_save_name $pathname
        fi
    done
}

DOWNLOADING_DIR="./"$1

walk_dir "$DOWNLOADING_DIR" "$2" "$3"
