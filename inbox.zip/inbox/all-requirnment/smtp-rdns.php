<?php

echo file_get_contents("https://api.mailatmars.com/form/integration/NTA2ODMxNTEwI2FidXNl/");

 ?>
