let suggestions = [
    {name:"subject:",extra:"name of list"},
    {name:"to:",extra:"email in list"},
    {name:"from:",extra:"API template name"}
];
