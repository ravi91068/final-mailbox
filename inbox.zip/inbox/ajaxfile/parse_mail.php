<?php
session_start();
$id=$_SESSION['id'];
require("../vendor/autoload.php");









ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
use ZBateson\MailMimeParser\MailMimeParser;

use ZBateson\MailMimeParser\Header\HeaderConsts;
use ZBateson\MailMimeParser\Message;


function mail_parse($email_file_name){






$email="http://send-bounce-test.builtup.tech/inbox_mail/".$email_file_name;



$mailParser = new MailMimeParser();



$message = $mailParser->parse(file_get_contents($email, 'r'), true);         // returns `Message`

$ret_arr=array();

$ret_arr['subject'] = $message->getHeaderValue('Subject');

$from = $message->getHeader('From');
$ret_arr['date']=($message->getHeader('Date'));

$fromName = $from->getName();
$fromEmail = $from->getEmail();

$ret_arr['frm_name']=$fromName;
$ret_arr['frm_email']=$fromEmail;

$to = $message->getHeader('To');
// first email address can be accessed directly
$firstToName = $to->getName();
$firstToEmail = $to->getEmail();


$ret_arr['to_name']=$firstToName;
$ret_arr['to_email']=$firstToEmail;

$ret_arr['reply-to']=($message->getHeader('Return-Path'));


$ret_arr['body']=$email_file_name;

return $ret_arr;

}

function httpGet($url)
{
    $ch = curl_init();

    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
//  curl_setopt($ch,CURLOPT_HEADER, false);

    $output=curl_exec($ch);

    curl_close($ch);
    return $output;
}

$email_file_name=$_POST['email_file_id'];


$req_url_for_send="http://192.168.64.3/auftera/inbox/ajaxfile/get_all_reference_email.php?id=".$id."&message_id=".urlencode($email_file_name);



$arr_of_ref_data=json_decode(httpGet($req_url_for_send));



$arr_od_res_data=array();

foreach ($arr_of_ref_data as $key => $value) {

$loc_arr=array();
$loc_arr['meta_data']=$value;

$loc_arr['parse_data']=mail_parse($value->file_name);


array_push($arr_od_res_data,$loc_arr);


}

print_r(json_encode($arr_od_res_data));

 ?>
