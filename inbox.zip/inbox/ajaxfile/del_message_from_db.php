<?php


function isrt_query_db($conn,$isrt_query){


if($conn->query($isrt_query)){

return 1;

}else{
        return $conn->error;
}


}



function select_query($conn,$sel_query){


        $ret_arr=array();

$result = $conn->query($sel_query);


if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {


    array_push($ret_arr,$row);
  }
}


return $ret_arr;
}


function move_to_trash_message_id($crm_conn,$message_id,$status_val){


  $update_query_for_del="update `recieve_email` set status='$status_val' where `file_name`='$message_id'";



  $update_linked_data_remove="update `recieve_email` set `in-reply`='' where `in-reply`='$message_id'";


  //$sel_email_that_refer="select `in-reply` from `recieve_email` where `file_name`='$message_id'";

  //$get_ref_id=select_query($crm_conn,$sel_email_that_refer)[0]['in-reply'];




  if(isrt_query_db($crm_conn,$update_query_for_del)){

return 1;
  }else{
    echo 0;
  }
}

require("../confige/crm.confige.php");

$message_id=$_POST['act_data_array'];
$status_def_val=$_POST['tag_status_val'];


$recieved_data=json_decode($message_id);



$status_arr=array("status"=>0,"message"=>"");

$remove_cnt=0;
foreach ($recieved_data as $key => $value) {
$remove_cnt+=move_to_trash_message_id($crm_conn,$value,$status_def_val);
}


echo json_encode(array("status"=>1,"message"=>$remove_cnt." Message Deleted"));

mysqli_close($crm_conn);
 ?>
