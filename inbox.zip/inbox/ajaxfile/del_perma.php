<?php

require("../confige/crm.confige.php");


function isrt_query_db($conn,$isrt_query){


if($conn->query($isrt_query)){

return 1;

}else{
        return $conn->error;
}


}

function httpGet($url)
{
    $ch = curl_init();

    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
//  curl_setopt($ch,CURLOPT_HEADER, false);

    $output=curl_exec($ch);

    curl_close($ch);
    return $output;
}

function del_email_in_db_file($conn,$message_id){
$del_query_in_db="delete from `recieve_email` where `file_name`='$message_id'";
if(isrt_query_db($conn,$del_query_in_db)){


  $email="http://send-bounce-test.builtup.tech/send/ajaxfile/del_mail_file.php?message_id=".urlencode($message_id);

return httpGet($email);


}

}

$req_data=json_decode($_POST['arr_of_data']);

$del_val_of_data=0;

foreach ($req_data as $key => $value) {
 $del_val_of_data+=del_email_in_db_file($crm_conn,$value);
}

echo json_encode(array("status"=>1,"message"=>$del_val_of_data." Permenant Delete"));
mysqli_close($crm_conn);

 ?>
