<?php
require("../vendor/autoload.php");
require("../confige/crm.confige.php");
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

use ZBateson\MailMimeParser\MailMimeParser;

use ZBateson\MailMimeParser\Header\HeaderConsts;
use ZBateson\MailMimeParser\Message;


function isrt_query_db($conn,$isrt_query){


if($conn->query($isrt_query)){

return 1;

}else{
        return $conn->error;
}


}

$email_file_name=$_GET['email_file_id'];

$email="http://send-bounce-test.builtup.tech/inbox_mail/".urlencode($email_file_name);


$update_query_for_open_tag="update `recieve_email` set `open`='1' where `file_name`='$email_file_name'";

isrt_query_db($crm_conn,$update_query_for_open_tag);


$mailParser = new MailMimeParser();



$message = $mailParser->parse(file_get_contents($email, 'r'), true);         // returns `Message`


$htmlStream = $message->getHtmlStream();

// or if you know you want a string:
$html_stream= $message->getHtmlContent();


// or if you know you want a string:

if(strlen($html_stream)>0){

echo "<base target='_blank' />".$html_stream;

}else{
  $txtStream = $message->getTextStream();
  $txt_stream= $txtStream->getContents();

echo $txt_stream;
}

mysqli_close($crm_conn);
?>
