<?php
session_start();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$id=$_SESSION['id'];


function conv_utc_to_loc($date,$tz){


        $given = new DateTime($date, new DateTimeZone("UTC"));
$given->setTimezone(new DateTimeZone($tz));
$output = $given->format("Y-m-d H:i:s");

return $output;

}

function select_query($conn,$sel_query,$tz){


        $ret_arr=array();

$result = $conn->query($sel_query);


if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {

//print_r($row);
$row['date']=conv_utc_to_loc($row['date'],$tz);
    array_push($ret_arr,$row);
  }
}


return $ret_arr;
}





require("../confige/crm.confige.php");


$email_client=$_POST['profile_name'];
$srch_fld=$_POST['srch_fld'];
$srch_val=$_POST['srch_val'];

$email_client=$_POST['profile_name'];

$ret_arr=array();
$get_tz_usr=file_get_contents("https://account.mailatmars.com/account/main/settings/ajaxfile/get_tz_of_usr.php?id=".$id);



$tz=json_decode($get_tz_usr)[0]->time_zone;

$srch_text_field="";


if(strlen($srch_val)>0){


    $sel_query="select * from `recieve_email` where `to`='$email_client'  and `".$srch_fld."`='".$srch_val."' ORDER BY date DESC";



}else if($srch_fld=='status'){


    $sel_query="select * from `recieve_email` where (`to`='$email_client' or `from`='$email_client')  and `".$srch_fld."`='".$srch_val."' ORDER BY date DESC";


}

//echo $sel_query;
//echo $sel_query;

print_r(json_encode(select_query($crm_conn,$sel_query,$tz)));

mysqli_close($crm_conn);
 ?>
