<?php
session_start();
if(isset($_GET['id'])){

$id=$_GET['id'];
}else{
$id=$_SESSION['id'];
}

function conv_utc_to_loc($date,$tz){


        $given = new DateTime($date, new DateTimeZone("UTC"));
$given->setTimezone(new DateTimeZone($tz));
$output = $given->format("Y-m-d H:i:s");

return $output;

}

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

function select_query($conn,$sel_query,$tz){


        $ret_arr=array();

$result = $conn->query($sel_query);


if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
$row['date']=conv_utc_to_loc($row['date'],$tz);

    array_push($ret_arr,$row);
  }
}


return $ret_arr;
}




require("../confige/crm.confige.php");

$all_arr=array();

function find_recurs_massage($crm_conn,$message_id,$tz){




$sel_query_for_ref="select * from `recieve_email` where `in-reply`='$message_id'";


$geted_data=select_query($crm_conn,$sel_query_for_ref,$tz);

if(count($geted_data)>0){
$find_email=$geted_data[0];

array_push($GLOBALS['all_arr'],$find_email);
if(strlen($find_email['in-reply'])>0){

find_recurs_massage($crm_conn,$find_email['file_name'],$tz);





}

}else{




}


}

$mess_email=$_GET['message_id'];
$sel_query_for_ref="select * from `recieve_email` where `file_name`='$mess_email'";



$get_tz_usr=file_get_contents("https://account.mailatmars.com/account/main/settings/ajaxfile/get_tz_of_usr.php?id=".$id);

$tz=json_decode($get_tz_usr)[0]->time_zone;




$find_email=select_query($crm_conn,$sel_query_for_ref,$tz)[0];



array_push($all_arr,$find_email);

find_recurs_massage($crm_conn,$mess_email,$tz);

print_r(json_encode(array_reverse($all_arr)));

mysqli_close($crm_conn);
