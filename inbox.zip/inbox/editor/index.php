<script src="//editor.unlayer.com/embed.js"></script>
<div id="editor-container"></div>
<script>

unlayer.init({
  id: 'editor-container',
  projectId: 1234,
  displayMode: 'email'
})
</script>
