<?php session_start();

$email=$_SESSION['email'];
$id=$_SESSION['id'];
require("./confige/fav_ico_conf.php");

?>
<html>
<head>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<style>
body{
  margin: 0px;
  font-family: 'Lato', sans-serif;
}

img.img-of-ico-bnt {
    height: 10px;
    padding-right: 10px;
  }
  .header-of-int-part {
    padding: 14px;
    border-bottom: 1px solid #80808029;
  }
  button.com-for-lnk {
    background: no-repeat;
    border: none;
      font-family: 'Lato', sans-serif;
  }
  button.com-for-lnk:hover {
    text-decoration: underline;
    cursor: pointer;
  }

  .con-of-main-int {
    padding: 40px;
    display: inline-flex;

}
.con-of-det-int {
    max-width: 30%;
    display: inline-block;
    width: 20%;
    padding-left: 5%;
  }
  .con-of-data-logo {
    padding: 20px 20px;
    background: #80808030;
    border-radius: 10px;
    text-align: center;
  }
  img.ico-con-of-int-logo {
    height: 100px;
    padding: 10px;
  }
  button.btn-try-out.com-for-lnk {
    margin-top: 10px;
    padding: 10px;
    background: white;
    border-radius: 10px;
  }
  .con-of-data-matter {
    margin-top: 40px;
  }
  .badge-name {
    color: #808080a3;
    text-transform: uppercase;
    font-size: 12px;
  }
  .badge-con {
    margin-top: 6px;
  }
  .con-of-inst-fot-int {
    width: 69%;
    display: inline-block;
    padding-left: 60px;
  }
  .use-case-span {
    background: #80808036;
    width: fit-content;
    padding: 4px 10px;
    border-radius: 10px;
    color: black;
    margin-top: 4px;
  }
  .name-of-con-main {
    font-size: 40px;
    font-weight: 800;
  }
  p.para-of-info-int {
    color: #0000007d;
    font-size: 16px;
    letter-spacing: .8px;
    line-height: 20px;
  }

  img.img-tut-install {
    border-radius: 20px;
    margin-top: 40px;
    margin-bottom: 40px;
    height: 300px;
    box-shadow: rgb(50 50 93 / 25%) 0px 6px 12px -2px, rgb(0 0 0 / 30%) 0px 3px 7px -3px;
  }
</style>
</head>
<body>

<div class="header-of-int-part">

<button class="btn-link-href com-for-lnk" data-for-serv="1" data-path-ses="dashboard/" data-target-link="https://dashboard.mailatmars.com/dashboard/"><img class="img-of-ico-bnt" src="https://res.cloudinary.com/heptera/image/upload/v1659505350/integration/arrow_back_ios_black_24dp_uobksr.svg">Go to Dashboard</button>

</div>


<div class="con-of-main-int">

    <div class="con-of-det-int">

        <div class="con-of-data-logo">

            <img class="ico-con-of-int-logo" src="https://res.cloudinary.com/heptera/image/upload/v1659506493/integration/wordpress_ernhvt.png">
            <br><span class="name-of-int">Wordpress</span>

            <br><button class="btn-try-out com-for-lnk" data-for-serv="1" data-path-ses="dashboard/" data-target-link="https://dashboard.mailatmars.com/dashboard/">Try It Free</button>


        </div>

        <div class="con-of-data-matter">
            <div class="badge-name">Developer</div>
            <div class="badge-con"><a href="">mailatmars</a></div>
        </div>

        <div class="con-of-data-matter">
            <div class="badge-name">Use Case</div>
            <div class="badge-con"><div class="use-case-span">Popup</div><div class="use-case-span">Modal</div><div class="use-case-span">Subscribe</div></div>
        </div>

        <div class="con-of-data-matter">
            <div class="badge-name">Price</div>
            <div class="badge-con">Free</div>
        </div>

        <div class="con-of-data-matter">
            <div class="badge-name">Support</div>
            <div class="badge-con"><a href="">mailatmars</a></div>
        </div>


    </div>
    <div class="con-of-inst-fot-int">

    <div class="name-of-con-main">Wordpress</div>
<p class="para-of-info-int">WordPress is a free and open-source platform that allows you to build quality websites, blogs, or apps. </p>
<p class="para-of-info-int">Use the Official MailatMars signup form plugin to add a newsletter signup form to your WordPress blog or website and seamlessly integrate it with your MailatMars account. </p>
<p class="para-of-info-int">Keep in mind you can only add embedded forms created in your MailatMars account. Popup forms are shown automatically on your WordPress site after the plugin has been activated. </p>

<h3 class="tag-of-int-setup">Set Up</h3>
<p class="para-of-info-int">

  <ul>
    <li>Download Wordpress Official Plugin from here <a href="https://res.cloudinary.com/heptera/raw/upload/v1659509473/integration/mailatmars_xi0fxs.zip">Download Now</a></li>
    <li>open your wordpress dashboard and click on plugin and add new plugin</li>
    <img class="img-tut-install" src="https://res.cloudinary.com/heptera/image/upload/v1659520579/integration/Screenshot_2022-08-03_at_12.32.15_PM_jvaa5p.png">
    <li>After click on upload plugin and select downloaded file that above mentioned and click to install</li>
    <img class="img-tut-install" src="https://res.cloudinary.com/heptera/image/upload/v1659520579/integration/Screenshot_2022-08-03_at_12.33.41_PM_lcthoq.png">
    <li>Next click mailatmars in left toolbar and save you API code from mailatmars console click to save</li>
      <img class="img-tut-install" src="https://res.cloudinary.com/heptera/image/upload/v1659520852/integration/Screenshot_2022-08-03_at_3.30.30_PM_piwj7u.png">
    <li>select your form that you created at mailatmars console.</li>

</ul>
</p>
<p class="para-of-info-int">2. After the plugin has been installed or placed in the folder, activate it on the WordPress admin panel. </p>

<p class="para-of-info-int">Once the plugin has been activated, you can create a custom signup form or select an embedded form created in your MailatMars account. The form can then be placed inside a post, a page, or a widget by using a shortcode. </p>



</div>


</div>

</body>

</html>

<script>


id='<?php echo $id;?>';
email='admin@auftera.com';

$(document).on('click','.com-for-lnk',function(){



$("#main-loader-containre").addClass("main-loader-containre-act");
$("#main-loader-containre").html('<div class="cp-spinner cp-round"></div>');

url_lnk=$(this).attr('data-target-link');
ses_path=$(this).attr('data-path-ses');


var sourceString = url_lnk.replace('http://','').replace('https://','').replace('www.','').split(/[/?#]/)[0];

if($(this).attr('data-for-serv')=='1'){

red_url="https://"+sourceString+"/"+ses_path+"confige/crt_ses.php?id="+id+"&email="+email+"&url_red="+url_lnk;

console.log(red_url);


}else if($(this).attr('data-for-serv')=='0'){



red_url=$(this).attr('data-target-link');





}

console.log(red_url);
window.location.href=red_url;


})
</script>
