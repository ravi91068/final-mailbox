<?php
/* Plugin name: Mailatmars Marketing
Plugin URI: http://mailatmars.com/integration/wordpress/
Description: This Plugin Help you to create subscribee pop-up and embeded subscribe form in your wordpress and you can directly added in your mailatmars account and make automation and campign for good visitor conversion.
Author: Mailatmars
URI: http://mailatmars.com/ Version: 0.5 */


function httpGet($token)
{

    $curl = curl_init();



curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.mailatmars.com/form/all/",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 40,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_HTTPHEADER => array(
    "Authorization: Bearer ".$token
  ),
));



$response = curl_exec($curl);



curl_close($curl);
return $response;
}

add_action( 'admin_menu', 'extra_post_info_menu' );  // Create WordPress admin menu
if( !function_exists("extra_post_info_menu") ) { function extra_post_info_menu(){    $page_title = 'Mailatmars Setting Page';   $menu_title = 'Mailatmars';   $capability = 'manage_options';   $menu_slug  = 'extra-post-info';   $function   = 'extra_post_info_page';   $icon_url   = 'https://res.cloudinary.com/heptera/image/upload/c_scale,h_20/v1656236951/logos/mailatmars_ym0wns.png';   $position   = 4;    add_menu_page( $page_title,                  $menu_title,                  $capability,                  $menu_slug,                  $function,                  $icon_url,                  $position );    // Call update_extra_post_info function to update database
add_action( 'admin_init', 'update_extra_post_info' );  } }  // Create function to register plugin settings in the database
if( !function_exists("update_extra_post_info") )
{ function update_extra_post_info()
{
    register_setting( 'extra-post-info-settings', 'api_key_mailatmars' );
    register_setting( 'extra-post-info-settings', 'form_name_of_show' );
     } }
     // Create WordPress plugin page
      if( !function_exists("extra_post_info_page") ) { function extra_post_info_page(){ ?>   <h1>MailatMars Marketing Plateform</h1>   <form method="post" action="options.php">     <?php settings_fields( 'extra-post-info-settings' ); ?>     <?php do_settings_sections( 'extra-post-info-settings' ); ?>     <table class="form-table">       <tr valign="top">       <th scope="row">API Key:</th>       <td><input type="text" name="api_key_mailatmars" value="<?php echo get_option('api_key_mailatmars'); ?>"/></td>       </tr>


      <?php


      $json_data_form=json_decode( httpGet(get_option('api_key_mailatmars')));


      ?>

      </tr>
      <tr valign="top">
      <th scope="row">Select Form From mailatmars Account:</th>




      <td>

      <select name="form_name_of_show" >
  <?php

foreach ($json_data_form as $value) {


echo '<option value="'.base64_encode($value->user_id."#".$value->form_name).'">'.$value->form_name.'</option>';
}
  ?>
</select>

      </td>
      </tr>

         </table>   <?php submit_button(); ?>   </form> <?php } }
      // Plugin logic for adding extra info to posts
      if( !function_exists("extra_post_info") ) {
          function extra_post_info($content)   {
          $extra_info = get_option('form_name_of_show');


           return $content.file_get_contents("https://api.mailatmars.com/form/integration/".$extra_info."/");


           }
      }




       add_filter('the_content', 'extra_post_info');


        ?>
