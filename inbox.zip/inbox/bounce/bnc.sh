rm new_virtual
rm new_virtual_domain



while IFS= read -r line; do
    echo $line >> /etc/postfix/new_virtual_domain
done < /etc/postfix/virtual_domain
line="/$2/"

echo $line >> /etc/postfix/new_virtual_domain

while IFS= read -r line; do
    echo $line >> /etc/postfix/new_virtual
done < /etc/postfix/virtual

line="/$1/  sammy"

echo $line >> /etc/postfix/new_virtual
rm /etc/postfix/virtual
rm /etc/postfix/virtual_domain
mv /etc/postfix/new_virtual_domain /etc/postfix/virtual_domain
mv /etc/postfix/new_virtual /etc/postfix/virtual
